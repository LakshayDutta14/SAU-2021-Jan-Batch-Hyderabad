const numbers = [1,2,3,4,5,6]  //input array

    const reduce = (reducer, initialValue, array) => {  //custom_reducer_function
      let value = initialValue;

      for(let i = 0; i < array.length; i++) {
        let currentValue = array[i]
        value = reducer(value, currentValue)
      }

      return value;
    }

const sumReducer = (initialValue, current) => initialValue + current;//the function to be executed again and again
const sumOfNumbersCustom = reduce(sumReducer, 0, numbers)//call the custom_reducer_function
console.log(sumOfNumbersCustom);