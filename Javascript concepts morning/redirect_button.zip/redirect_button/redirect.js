function myFunction()
{
    alert("Thanks for visiting my Site !");
}