function fn(){
    var a =  document.getElementById("first").value;
    var b =  document.getElementById("second").value;
    var c = parseInt(a) + parseInt(b); 
    console.log(c);
    document.getElementById("result").value=c;
}