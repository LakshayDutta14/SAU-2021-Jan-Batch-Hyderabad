function myFunction()
{
    alert("HELLO WORLD");
}